const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const path = require('path');
const crypto = require('crypto');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
    pingTimeout: 60000,
    pingInterval: 25000,
    cors: {
        origin: "*",
        methods: ["GET", "POST"]
    },
    perMessageDeflate: {
        threshold: 1024
    }
});

// Configurações
let rooms = [];
const MAX_PLAYERS = 7;
const messageLimiter = {};

// Funções auxiliares
function generateRoomCode() {
    let code;
    do {
        code = Math.floor(1000 + Math.random() * 9000);
    } while (rooms.some(r => r.code === code));
    return code;
}

function getPublicRooms() {
    return rooms.map(room => ({
        code: room.code,
        owner: room.owner,
        type: room.type,
        playerCount: room.players.length,
        maxPlayers: MAX_PLAYERS,
        hasPassword: !!room.password
    }));
}

function sanitizeInput(input) {
    return input.toString()
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;')
        .substring(0, 100);
}

function hashPassword(password) {
    if (!password) return null;
    return crypto.createHash('sha256').update(password).digest('hex');
}

function logEvent(event, socketId, details = {}) {
    const timestamp = new Date().toISOString();
    console.log(`[${timestamp}] ${event} - ${socketId}`, details);
}

// Atualização em tempo real
function updateAllClients() {
    io.emit('updateRoomList', getPublicRooms());
    rooms.forEach(room => {
        io.to(room.code).emit('updatePlayers', room.players);
    });
}

// Socket.IO
io.on('connection', (socket) => {
    logEvent('CONNECTION', socket.id);

// Dentro do io.on('connection', ...)
socket.on('canStartGame', (roomCode, callback) => {
    const room = rooms.find(r => r.code === roomCode);
    if (!room) return callback({ canStart: false });
    
    callback({ 
        canStart: room.players.length === 7 
    });
});

socket.on('startGame', (roomCode, callback) => {
    const room = rooms.find(r => r.code === roomCode);
    if (!room) return callback({ success: false, error: "Sala não encontrada" });

    if (room.players.length < 7) {
        return callback({ success: false, error: "Ainda não há 7 jogadores" });
    }

    // Emite para todos na sala redirecionarem
    io.to(roomCode).emit('redirectToGame', {
        roomCode: roomCode,
        players: room.players.map(p => p.name)
    });

    callback({ success: true });
});

// Quando um jogador entra na página do jogo
socket.on('joinGameRoom', (data) => {
    const room = rooms.find(r => r.code === data.roomCode);
    if (!room) return;
    
    socket.join(data.roomCode);
    console.log(`${data.playerName} entrou na página do jogo da sala ${data.roomCode}`);
    
    // Você pode enviar o estado inicial do jogo aqui
    socket.emit('gameStart', {
        room: room,
        role: 'lobisomem' // ou outra lógica para definir papéis
    });
});

// Quando recebe uma ação do jogo
socket.on('gameAction', (data) => {
    // Processe a ação e envie atualizações para todos
    io.to(data.roomCode).emit('gameUpdate', {
        action: data.action,
        player: data.playerName,
        // ... outros dados do jogo ...
    });
});

    // Restauração de sessão
    socket.on('restoreSession', (data, callback) => {
        const room = rooms.find(r => r.code === data.roomCode);
        if (room && room.players.some(p => p.name === data.playerName)) {
            socket.join(data.roomCode);
            const player = room.players.find(p => p.name === data.playerName);
            callback({ 
                restored: true, 
                isAdmin: player.isAdmin,
                isCreator: player.isCreator,
                players: room.players,
                roomOwner: room.owner
            });
            logEvent('SESSION_RESTORED', socket.id, { room: data.roomCode, player: data.playerName });
        } else {
            callback({ restored: false });
        }
    });

    // Validação de nickname
    socket.on('checkNickname', (name, callback) => {
        try {
            const sanitizedName = sanitizeInput(name).trim();
            
            if (sanitizedName.length < 3 || sanitizedName.length > 20) {
                return callback({ available: false, message: "Nome deve ter 3-20 caracteres" });
            }
            
            const nameRegex = /^[a-zA-ZÀ-ÿ0-9][a-zA-ZÀ-ÿ0-9 ]{2,19}$/;
            if (!nameRegex.test(sanitizedName)) {
                return callback({ available: false, message: "Use apenas letras, números e espaços" });
            }
            
            const isNameInUse = rooms.some(room => 
                room.players.some(player => 
                    player.name.toLowerCase() === sanitizedName.toLowerCase()
                )
            );
            
            callback({
                available: !isNameInUse,
                message: isNameInUse ? "Nome já está em uso" : "Nome disponível"
            });
        } catch (error) {
            logEvent('NICKNAME_ERROR', socket.id, { error: error.message });
            callback({ available: false, message: "Erro ao validar nome" });
        }
    });

    // Criação de sala
    socket.on('createRoom', (data, callback) => {
        try {
            const sanitizedName = sanitizeInput(data.owner).trim();
            const password = data.type === 'private' ? hashPassword(data.password) : null;
            
            // Verificar se já está em outra sala
            const playerInRoom = rooms.some(r => 
                r.players.some(p => p.name.toLowerCase() === sanitizedName.toLowerCase())
            );
            
            if (playerInRoom) {
                return callback({ success: false, error: "Você já está em uma sala. Saia primeiro para criar outra." });
            }

            const roomCode = generateRoomCode();
            const newRoom = {
                code: roomCode,
                owner: sanitizedName,
                players: [{
                    name: sanitizedName,
                    socketId: socket.id,
                    isAdmin: true,
                    isCreator: true
                }],
                password: password,
                type: data.type,
                createdAt: new Date()
            };

            rooms.push(newRoom);
            socket.join(roomCode);
            socket.playerName = sanitizedName;
            
            callback({ 
                success: true, 
                roomCode, 
                isAdmin: true,
                isCreator: true,
                players: newRoom.players
            });
            
            io.to(roomCode).emit('receiveMessage', {
                sender: 'Sistema',
                message: `👑 ${sanitizedName} criou a sala`,
                color: 'gold',
                timestamp: new Date()
            });
            
            updateAllClients();
            logEvent('ROOM_CREATED', socket.id, { room: roomCode });
        } catch (error) {
            logEvent('ROOM_CREATION_ERROR', socket.id, { error: error.message });
            callback({ success: false, error: "Erro ao criar sala" });
        }
    });

    // Entrar em sala
    socket.on('joinRoom', (data, callback) => {
        try {
            const sanitizedName = sanitizeInput(data.playerName).trim();
            const room = rooms.find(r => r.code === data.roomCode);
            
            if (!room) return callback({ success: false, error: "Sala não encontrada" });
            if (room.players.length >= MAX_PLAYERS) {
                return callback({ success: false, error: "Sala cheia" });
            }

            // Verificar se já está em outra sala
            const playerInRoom = rooms.some(r => 
                r.players.some(p => p.name.toLowerCase() === sanitizedName.toLowerCase())
            );
            
            if (playerInRoom) {
                return callback({ 
                    success: false, 
                    error: "Você já está em uma sala. Saia primeiro para entrar em outra." 
                });
            }

            // Verificar senha para sala privada
            if (room.type === "private") {
                const hashedPassword = hashPassword(data.password || '');
                if (hashedPassword !== room.password) {
                    return callback({ success: false, error: "Senha incorreta" });
                }
            }

            const newPlayer = {
                name: sanitizedName,
                socketId: socket.id,
                isAdmin: false,
                isCreator: false
            };
            room.players.push(newPlayer);
            socket.join(room.code);
            socket.playerName = sanitizedName;
            
            callback({ 
                success: true,
                roomCode: room.code,
                isAdmin: false,
                isCreator: false,
                players: room.players,
                roomOwner: room.owner
            });
            
            io.to(room.code).emit('receiveMessage', {
                sender: 'Sistema',
                message: `🎉 ${sanitizedName} entrou na sala`,
                color: 'green',
                timestamp: new Date()
            });
            
            updateAllClients();
            logEvent('PLAYER_JOINED', socket.id, { room: room.code, player: sanitizedName });
        } catch (error) {
            logEvent('JOIN_ERROR', socket.id, { error: error.message });
            callback({ success: false, error: "Erro ao entrar na sala" });
        }
    });

    // Funções de ADM
    socket.on('adminAction', (data, callback) => {
        try {
            const room = rooms.find(r => r.code === data.roomCode);
            if (!room) return callback({ success: false, error: "Sala não encontrada" });

            const admin = room.players.find(p => p.socketId === socket.id);
            if (!admin || !admin.isAdmin) {
                return callback({ success: false, error: "Acesso negado" });
            }

            if (data.action !== 'deleteRoom') {
                const targetPlayer = room.players.find(p => p.name === data.targetPlayer);
                if (!targetPlayer) {
                    return callback({ success: false, error: "Jogador não encontrado" });
                }

                // Verificar hierarquia de permissões
                if (targetPlayer.isCreator) {
                    return callback({ success: false, error: "Não pode modificar o criador da sala" });
                }

                // ADMs comuns não podem modificar outros ADMs (apenas o criador pode)
                if (targetPlayer.isAdmin && !admin.isCreator) {
                    return callback({ success: false, error: "Apenas o criador pode modificar outros ADMs" });
                }

                switch (data.action) {
                    case 'kick':
                        room.players = room.players.filter(p => p.name !== data.targetPlayer);
                        io.to(targetPlayer.socketId).emit('kicked');
                        io.to(room.code).emit('receiveMessage', {
                            sender: 'Sistema',
                            message: `🚫 ${data.targetPlayer} foi expulso por ${admin.name}`,
                            color: 'red',
                            timestamp: new Date()
                        });
                        break;

                    case 'promote':
                        if (admin.isCreator) {
                            targetPlayer.isAdmin = true;
                            io.to(targetPlayer.socketId).emit('adminStatus', { 
                                isAdmin: true 
                            });
                            io.to(room.code).emit('receiveMessage', {
                                sender: 'Sistema',
                                message: `👑 ${data.targetPlayer} foi promovido a ADM por ${admin.name}`,
                                color: 'gold',
                                timestamp: new Date()
                            });
                        } else {
                            return callback({ success: false, error: "Apenas o criador pode promover ADMs" });
                        }
                        break;

                    case 'demote':
                        if (admin.isCreator) {
                            targetPlayer.isAdmin = false;
                            io.to(targetPlayer.socketId).emit('adminStatus', { 
                                isAdmin: false 
                            });
                            io.to(room.code).emit('receiveMessage', {
                                sender: 'Sistema',
                                message: `🔻 ${data.targetPlayer} foi rebaixado por ${admin.name}`,
                                color: 'gold',
                                timestamp: new Date()
                            });
                        } else {
                            return callback({ success: false, error: "Apenas o criador pode rebaixar ADMs" });
                        }
                        break;

                    default:
                        return callback({ success: false, error: "Ação inválida" });
                }
            } else {
                // Ação de deletar sala
                if (admin.isCreator) {
                    io.to(room.code).emit('roomDeleted');
                    rooms = rooms.filter(r => r.code !== room.code);
                    updateAllClients();
                    return callback({ success: true });
                } else {
                    return callback({ success: false, error: "Apenas o criador pode deletar a sala" });
                }
            }

            updateAllClients();
            callback({ success: true });
            logEvent('ADMIN_ACTION', socket.id, { 
                action: data.action, 
                room: data.roomCode, 
                target: data.targetPlayer 
            });
        } catch (error) {
            logEvent('ADMIN_ACTION_ERROR', socket.id, { error: error.message });
            callback({ success: false, error: "Erro ao executar ação" });
        }
    });

    // Chat
    socket.on('sendMessage', (data, callback) => {
        try {
            if (!messageLimiter[socket.id]) {
                messageLimiter[socket.id] = { count: 0, last: Date.now() };
            }

            const now = Date.now();
            if (now - messageLimiter[socket.id].last < 1000) {
                messageLimiter[socket.id].count++;
                if (messageLimiter[socket.id].count > 3) {
                    return callback({ success: false, error: "Muitas mensagens rápidas!" });
                }
            } else {
                messageLimiter[socket.id] = { count: 1, last: now };
            }

            const sanitizedMessage = sanitizeInput(data.message);
            io.to(data.roomCode).emit('receiveMessage', {
                sender: data.sender,
                message: sanitizedMessage,
                color: 'black',
                timestamp: new Date()
            });
            
            callback({ success: true });
        } catch (error) {
            logEvent('MESSAGE_ERROR', socket.id, { error: error.message });
            callback({ success: false, error: "Erro ao enviar mensagem" });
        }
    });

    // Indicador de digitação
    socket.on('typing', (data) => {
        socket.to(data.roomCode).emit('typing', {
            name: data.name,
            isTyping: data.isTyping
        });
    });

    // Sair da sala
    socket.on('leaveRoom', (data) => {
        const room = rooms.find(r => r.code === data.roomCode);
        if (!room) return;

        const playerIndex = room.players.findIndex(p => p.name === data.playerName);
        if (playerIndex !== -1) {
            room.players.splice(playerIndex, 1);
            
            io.to(room.code).emit('receiveMessage', {
                sender: 'Sistema',
                message: `🚪 ${data.playerName} saiu da sala`,
                color: 'red',
                timestamp: new Date()
            });

            if (room.players.length === 0) {
                rooms = rooms.filter(r => r.code !== room.code);
                logEvent('ROOM_DELETED', socket.id, { room: room.code, reason: 'empty' });
            }
            
            updateAllClients();
        }
    });

    // Desconexão
    socket.on('disconnect', () => {
        logEvent('DISCONNECT', socket.id);
        rooms.forEach((room, roomIndex) => {
            const playerIndex = room.players.findIndex(p => p.socketId === socket.id);
            if (playerIndex !== -1) {
                const playerName = room.players[playerIndex].name;
                const wasAdmin = room.players[playerIndex].isAdmin;
                const wasCreator = room.players[playerIndex].isCreator;
                
                room.players.splice(playerIndex, 1);
                
                if (room.players.length === 0) {
                    rooms.splice(roomIndex, 1);
                    logEvent('ROOM_DELETED', socket.id, { room: room.code, reason: 'empty' });
                } else {
                    if (wasCreator) {
                        // Transferir criação da sala para o primeiro jogador disponível
                        const newCreator = room.players[0];
                        newCreator.isCreator = true;
                        newCreator.isAdmin = true;
                        room.owner = newCreator.name;
                        
                        io.to(newCreator.socketId).emit('adminStatus', { 
                            isAdmin: true, 
                            isCreator: true 
                        });
                        
                        io.to(room.code).emit('receiveMessage', {
                            sender: 'Sistema',
                            message: `👑 ${newCreator.name} é o novo criador da sala`,
                            color: 'gold',
                            timestamp: new Date()
                        });
                    } else if (wasAdmin && !room.players.some(p => p.isAdmin)) {
                        // Promover novo ADM (o primeiro jogador da lista)
                        room.players[0].isAdmin = true;
                        io.to(room.players[0].socketId).emit('adminStatus', { 
                            isAdmin: true 
                        });
                        
                        io.to(room.code).emit('receiveMessage', {
                            sender: 'Sistema',
                            message: `⭐ ${room.players[0].name} é o novo ADM`,
                            color: 'gold',
                            timestamp: new Date()
                        });
                    }
                    
                    io.to(room.code).emit('receiveMessage', {
                        sender: 'Sistema',
                        message: `🚪 ${playerName} saiu da sala`,
                        color: 'red',
                        timestamp: new Date()
                    });
                }

                updateAllClients();
            }
        });
    });
});

// Atualização periódica para sincronização
setInterval(() => {
    updateAllClients();
}, 1000);

// Configuração do Express
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'login.html'));
});
app.get('/jogo.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'jogo.html'));
});
app.get('/jogo.css', (req, res) => {
    res.sendFile(path.join(__dirname, 'jogo.css'));
});

app.get('/jogo.js', (req, res) => {
    res.sendFile(path.join(__dirname, 'jogo.js'));
});
app.get('/login.css', (req, res) => {
    res.sendFile(path.join(__dirname, 'login.css'));
});

app.get('/login.js', (req, res) => {
    res.sendFile(path.join(__dirname, 'login.js'));
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
}); 