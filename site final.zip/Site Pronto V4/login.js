// Variáveis globais
let socket;
let rooms = [];
let currentRoom = null;
let playerName = null;
let isAdmin = false;
let isCreator = false;
let roomOwner = null;
let typingTimeout = null;
let unreadMessages = 0;

// Elementos do DOM
const elements = {
    playerName: document.getElementById("playerName"),
    validateNicknameButton: document.getElementById("validateNicknameButton"),
    changeNameButton: document.getElementById("changeNameButton"),
    nameError: document.getElementById("nameError"),
    roomControls: document.getElementById("roomControls"),
    roomType: document.getElementById("roomType"),
    passwordField: document.getElementById("passwordField"),
    roomPassword: document.getElementById("roomPassword"),
    createRoomButton: document.getElementById("createRoomButton"),
    leaveButton: document.getElementById("leaveButton"),
    roomInfo: document.getElementById("roomInfo"),
    searchRoomCode: document.getElementById("searchRoomCode"),
    searchRoomButton: document.getElementById("searchRoomButton"),
    roomsCount: document.getElementById("roomsCount"),
    startGameButton: document.getElementById("startGameButton"),
    playersCount: document.getElementById("playersCount"),
    roomsList: document.getElementById("roomsList"),
    playersList: document.getElementById("playersList"),
    chatToggle: document.getElementById("chatToggle"),
    chatBoxContainer: document.getElementById("chatBoxContainer"),
    chatMessages: document.getElementById("chatMessages"),
    messageInput: document.getElementById("messageInput"),
    sendMessageButton: document.getElementById("sendMessageButton"),
    adminControls: document.getElementById("adminControls"),
    deleteRoomButton: document.getElementById("deleteRoomButton")
};

// Inicialização do Socket.IO
function initSocket() {
    socket = io({
        reconnection: true,
        reconnectionAttempts: 5,
        reconnectionDelay: 1000
    });

    socket.on('redirectToGame', (data) => {
        window.location.href = `jogo.html?room=${data.roomCode}&player=${encodeURIComponent(playerName)}`;
    });
    

    // Event listeners
    socket.on('connect', () => {
        console.log('Conectado ao servidor');
        displayMessage("✅ Conectado ao servidor", "success");
        
        // Tentar restaurar sessão se existir
        const sessionData = JSON.parse(sessionStorage.getItem('werewolfSession'));
        if (sessionData && sessionData.playerName) {
            socket.emit('restoreSession', {
                playerName: sessionData.playerName,
                roomCode: sessionData.roomCode
            }, (response) => {
                if (response.success) {
                    handleSuccessfulLogin(response);
                } else {
                    sessionStorage.removeItem('werewolfSession');
                }
            });
        }
    });

    // Adicione isso na função initSocket(), depois dos outros socket.on()
socket.on('gameStarted', (data) => {
    displayMessage("🎮 O jogo está começando! Redirecionando...", "success");
    setTimeout(() => {
        window.location.href = "jogo.html?room=" + data.roomCode + "&player=" + encodeURIComponent(playerName);
    }, 2000);
});

    socket.on('disconnect', () => {
        displayMessage("⚠️ Conexão perdida. Reconectando...", "error");
    });

    socket.on('connect_error', () => {
        displayMessage("❌ Falha na conexão com o servidor", "error");
    });

    socket.on('updateRoomList', (roomList) => {
        rooms = roomList;
        updateRoomList();
    });

    socket.on('updatePlayers', (players) => {
        updatePlayersList(players);
        elements.playersCount.textContent = players.length;
    });

    socket.on('receiveMessage', (data) => {
        addMessageToChat(data.sender, data.message, data.type);
    });

    socket.on('typing', (data) => {
        showTypingIndicator(data.name, data.isTyping);
    });

    socket.on('kicked', handleKicked);
    socket.on('roomDeleted', handleRoomDeleted);
    socket.on('adminStatus', (data) => {
        isAdmin = data.isAdmin;
        isCreator = data.isCreator || false;
        roomOwner = data.roomOwner;
        updateAdminControls();
    });

    // Configuração de eventos
    setupEventListeners();
}

function toggleNameChange(locked) {
    elements.changeNameButton.style.display = locked ? "none" : "block";
    elements.playerName.disabled = locked;
    elements.validateNicknameButton.disabled = locked;
    
    if (locked) {
        elements.validateNicknameButton.textContent = "✔ Nome Validado";
        elements.validateNicknameButton.classList.add("validated");
    } else {
        elements.validateNicknameButton.textContent = "Validar Nome";
        elements.validateNicknameButton.classList.remove("validated");
    }
}


// Funções auxiliares
function saveSession() {
    const sessionData = {
        playerName: playerName,
        roomCode: currentRoom,
        isAdmin: isAdmin,
        isCreator: isCreator,
        timestamp: Date.now()
    };
    sessionStorage.setItem('werewolfSession', JSON.stringify(sessionData));
}

function clearSession() {
    sessionStorage.removeItem('werewolfSession');
}

function displayMessage(msg, type) {
    elements.roomInfo.textContent = msg;
    elements.roomInfo.className = `info-message ${type}`;
    setTimeout(() => {
        elements.roomInfo.textContent = '';
        elements.roomInfo.className = 'info-message';
    }, 5000);
}

function updateAdminControls() {
    elements.adminControls.style.display = isAdmin ? "block" : "none";
    elements.deleteRoomButton.style.display = isCreator ? "block" : "none";
}

// Funções do Chat
function addMessageToChat(sender, message, type = 'normal') {
    const messageElement = document.createElement("div");
    messageElement.className = `message ${type}`;
    
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    
    messageElement.innerHTML = `
    <span class="message-time">[${time}]</span>
    <span class="message-sender">${sender}:</span>
    <span class="message-content">${message}</span>
`;
    
elements.chatMessages.appendChild(messageElement);
elements.chatMessages.scrollTop = elements.chatMessages.scrollHeight;
}

function showTypingIndicator(name, isTyping) {
    clearTypingIndicator();
    
    if (isTyping && name !== playerName) {
        const indicator = document.createElement("div");
        indicator.className = "typing-indicator";
        indicator.textContent = `${name} está digitando...`;
        indicator.id = "typingIndicator";
        elements.chatMessages.appendChild(indicator);
        elements.chatMessages.scrollTop = elements.chatMessages.scrollHeight;
        
        // Configura timeout para remover o indicador após 3 segundos
        typingTimeout = setTimeout(() => {
            clearTypingIndicator();
        }, 3000);
    }
}

// Adicione esta nova função
function updateChatNotification() {
    const toggle = elements.chatToggle;
    if (unreadMessages > 0) {
        toggle.classList.add("has-unread");
        toggle.setAttribute("data-count", unreadMessages > 9 ? "9+" : unreadMessages);
        
        // Adicionar contador dentro do pseudo-elemento
        toggle.style.setProperty('--unread-count', `"${unreadMessages > 9 ? '9+' : unreadMessages}"`);
    } else {
        toggle.classList.remove("has-unread");
        toggle.removeAttribute("data-count");
    }
}

function clearTypingIndicator() {
    if (typingTimeout) {
        clearTimeout(typingTimeout);
        typingTimeout = null;
    }
    const indicator = document.getElementById("typingIndicator");
    if (indicator) {
        indicator.remove();
    }
}

function sendMessage() {
    const message = elements.messageInput.value.trim();
    if (!message || !currentRoom) return;
    
    socket.emit('sendMessage', {
        roomCode: currentRoom,
        sender: playerName,
        message: message
    }, (response) => {
        if (response && response.success) {
            elements.messageInput.value = "";
            // Notificar que parou de digitar
            socket.emit('typing', {
                roomCode: currentRoom,
                name: playerName,
                isTyping: false
            });
        } else {
            displayMessage(`❌ ${response.error}`, "error");
        }
    });
}

function updateStartButton(playerCount) {
    const btn = elements.startGameButton;
    btn.disabled = playerCount !== 7;
    btn.textContent = `🎮 Iniciar Jogo (${playerCount}/7)`;
    
    // Estilização condicional (o trecho que você perguntou)
    if (btn.disabled) {
        btn.style.opacity = "0.7";
        btn.style.cursor = "not-allowed";
    } else {
        btn.style.opacity = "1";
        btn.style.cursor = "pointer";
    }
}

// Modifique a função validateNickname para:
function validateNickname() {
    const name = elements.playerName.value.trim();
    elements.nameError.textContent = "";

    if (name.length < 3 || name.length > 20) {
        elements.nameError.textContent = "Nome deve ter entre 3 e 20 caracteres";
        return;
    }

    const nameRegex = /^[a-zA-ZÀ-ÿ0-9][a-zA-ZÀ-ÿ0-9 ]{2,19}$/;
    if (!nameRegex.test(name)) {
        elements.nameError.textContent = "Use apenas letras, números e espaços";
        return;
    }

    socket.emit('checkNickname', name, (response) => {
        if (response.available) {
            playerName = name;
            elements.playerName.disabled = true;
            elements.validateNicknameButton.disabled = true;
            elements.validateNicknameButton.textContent = "✔ Nome Validado";
            elements.validateNicknameButton.classList.add("validated");
            elements.changeNameButton.style.display = "block";
            elements.roomControls.style.display = "block";
            displayMessage("✅ Nome validado com sucesso", "success");
            saveSession();
        } else {
            elements.nameError.textContent = response.message;
        }
    });
}
// Atualizar lista de salas
function updateRoomList() {
    elements.roomsList.innerHTML = "";
    
    if (currentRoom) {
        elements.roomsList.innerHTML = "<li class='room-item'>Você já está em uma sala. Saia primeiro para entrar em outra.</li>";
        elements.roomsCount.textContent = "0";
        return;
    }

    const searchCode = elements.searchRoomCode.value;
    let filteredRooms = rooms;

    if (searchCode.length > 0) {
        filteredRooms = rooms.filter(room => 
            room.code.toString().startsWith(searchCode)
        );
    }

    elements.roomsCount.textContent = filteredRooms.length;

    if (filteredRooms.length === 0) {
        const message = searchCode.length > 0 
            ? `Nenhuma sala encontrada começando com ${searchCode}` 
            : "Nenhuma sala disponível";
        elements.roomsList.innerHTML = `<li class='room-item'>${message}</li>`;
        return;
    }

    filteredRooms.forEach(room => {
        const li = document.createElement("li");
        li.className = "room-item";
        
        const roomInfo = document.createElement("div");
        roomInfo.className = "room-info";
        roomInfo.innerHTML = `
            <span class="room-code">Sala ${room.code}</span>
            <span class="room-players">${room.playerCount}/${room.maxPlayers}</span>
            <span class="room-type">${room.type === 'public' ? '🌐' : '🔒'}</span>
        `;
        
        const joinButton = document.createElement("button");
        joinButton.className = "join-button";
        joinButton.textContent = "Entrar";
        joinButton.onclick = () => joinRoom(room.code);
        
        li.appendChild(roomInfo);
        if (room.playerCount < room.maxPlayers) {
            li.appendChild(joinButton);
        }
        
        elements.roomsList.appendChild(li);
    });
}

// Atualizar lista de jogadores
function updatePlayersList(players) {
    elements.playersList.innerHTML = "";
    
    if (!players || players.length === 0) {
        elements.playersList.innerHTML = "<li class='player-item'>Nenhum jogador na sala</li>";
        elements.playersCount.textContent = "0/7";
        updateStartButton(0);
        return;
    }

    elements.playersCount.textContent = `${players.length}/7`;
    updateStartButton(players.length);
  
    players.forEach(player => {
        const li = document.createElement("li");
        li.className = "player-item";
        
        const playerInfo = document.createElement("div");
        playerInfo.className = "player-info";
        
        const playerNameSpan = document.createElement("span");
        playerNameSpan.className = "player-name";


        
        
        if (player.isCreator) {
            playerNameSpan.innerHTML = `👑 ${player.name} (Criador)`;
        } else if (player.isAdmin) {
            playerNameSpan.innerHTML = `⭐ ${player.name} (ADM)`;
        } else {
            playerNameSpan.textContent = player.name;
        }
        
        playerInfo.appendChild(playerNameSpan);
        li.appendChild(playerInfo);

        
        
        if (isCreator && player.name !== playerName) {
            const actionsDiv = document.createElement("div");
            actionsDiv.className = "player-actions";
            
            if (!player.isCreator) {
                if (player.isAdmin) {
                    const demoteButton = document.createElement("button");
                    demoteButton.className = "demote-button";
                    demoteButton.textContent = "Rebaixar";
                    demoteButton.onclick = () => adminAction('demote', player.name);
                    actionsDiv.appendChild(demoteButton);
                } else {
                    const promoteButton = document.createElement("button");
                    promoteButton.className = "promote-button";
                    promoteButton.textContent = "Promover";
                    promoteButton.onclick = () => adminAction('promote', player.name);
                    actionsDiv.appendChild(promoteButton);
                }
            }
            
            const kickButton = document.createElement("button");
            kickButton.className = "kick-button";
            kickButton.textContent = "Expulsar";
            kickButton.onclick = () => adminAction('kick', player.name);
            actionsDiv.appendChild(kickButton);
            
            li.appendChild(actionsDiv);
        }
        else if (isAdmin && !isCreator && !player.isAdmin && !player.isCreator) {
            const actionsDiv = document.createElement("div");
            actionsDiv.className = "player-actions";
            
            const kickButton = document.createElement("button");
            kickButton.className = "kick-button";
            kickButton.textContent = "Expulsar";
            kickButton.onclick = () => adminAction('kick', player.name);
            actionsDiv.appendChild(kickButton);
            
            li.appendChild(actionsDiv);
        }
        
        elements.playersList.appendChild(li);
    });
}



// Ações de ADM
async function adminAction(action, targetPlayer) {
    let confirmationMessage = '';
    
    switch(action) {
        case 'kick':
            confirmationMessage = `Tem certeza que deseja expulsar ${targetPlayer}?`;
            break;
        case 'promote':
            confirmationMessage = `Tem certeza que deseja promover ${targetPlayer} a ADM?`;
            break;
        case 'demote':
            confirmationMessage = `Tem certeza que deseja rebaixar ${targetPlayer}?`;
            break;
        default:
            return;
    }
    
    const confirmed = confirm(confirmationMessage);
    if (!confirmed) return;
    
    socket.emit('adminAction', {
        roomCode: currentRoom,
        action: action,
        targetPlayer: targetPlayer
    }, (response) => {
        if (!response.success) {
            displayMessage(`❌ ${response.error}`, "error");
        }
    });
}

// Deletar sala
async function deleteRoom() {
    const confirmed = confirm(
        "Tem certeza que deseja deletar esta sala? Todos os jogadores serão desconectados!"
    );
    
    if (!confirmed) return;
    
    socket.emit('adminAction', {
        roomCode: currentRoom,
        action: 'deleteRoom'
    }, (response) => {
        if (!response.success) {
            displayMessage(`❌ ${response.error}`, "error");
        }
    });
}

// Criar sala
function createRoom() {
    if (currentRoom) {
        displayMessage("⚠️ Você já está em uma sala. Saia primeiro para criar outra.", "error");
        return;
    }

    const roomType = elements.roomType.value;
    const password = elements.roomPassword.value.trim();
    
    if (roomType === "private" && (!password || password.length < 4)) {
        displayMessage("⚠️ Senha deve ter pelo menos 4 caracteres", "error");
        return;
    }

    elements.createRoomButton.disabled = true;
    elements.createRoomButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Criando...';
    
    socket.emit('createRoom', {
        owner: playerName,
        type: roomType,
        password: password
    }, (response) => {
        elements.createRoomButton.disabled = false;
        elements.createRoomButton.innerHTML = '🛠 Criar Sala';
        
        if (response.success) {
            handleSuccessfulLogin(response);
            displayMessage(`✅ Sala ${currentRoom} criada`, "success");
        } else {
            displayMessage(`❌ ${response.error}`, "error");
        }
    });
}

// Entrar em sala
async function joinRoom(roomCode) {
    if (currentRoom) {
        displayMessage("⚠️ Você já está em uma sala. Saia primeiro para entrar em outra.", "error");
        return;
    }

    const room = rooms.find(r => r.code === roomCode);
    if (!room) {
        displayMessage("⚠️ Sala não encontrada", "error");
        return;
    }

    let password = "";
    if (room.type === "private") {
        password = prompt("Digite a senha da sala:");
        if (password === null) return;
    }

    socket.emit('joinRoom', {
        roomCode: roomCode,
        playerName: playerName,
        password: password
    }, (response) => {
        if (response.success) {
            handleSuccessfulLogin(response);
            displayMessage(`✅ Entrou na sala ${currentRoom}`, "success");
        } else {
            displayMessage(`❌ ${response.error}`, "error");
        }
    });
}

function handleSuccessfulLogin(response) {
    currentRoom = response.roomCode;
    isAdmin = response.isAdmin;
    isCreator = response.isCreator || false;
    roomOwner = response.roomOwner;
    
    elements.leaveButton.style.display = "block";
    elements.chatBoxContainer.style.display = "block";
    elements.chatBoxContainer.classList.add("active");
    
    // Bloquear alteração do nome
    toggleNameChange(true);
    
    updateAdminControls();
    updatePlayersList(response.players);
    updateRoomList();
    saveSession();
}

// Sair da sala
function leaveRoom() {
    if (!currentRoom) return;
    
    socket.emit('leaveRoom', {
        roomCode: currentRoom,
        playerName: playerName
    });
    
    currentRoom = null;
    isAdmin = false;
    isCreator = false;
    roomOwner = null;
    
    elements.leaveButton.style.display = "none";
    elements.chatBoxContainer.style.display = "none";
    elements.adminControls.style.display = "none";
    elements.playersList.innerHTML = "";
    elements.chatMessages.innerHTML = "";
    
    // Permitir alteração do nome novamente
    toggleNameChange(false);
    
    updateRoomList();
    displayMessage("🚪 Você saiu da sala", "success");
    clearSession();
}

function handleKicked() {
    displayMessage("🚫 Você foi expulso da sala", "error");
    leaveRoom();
}

function handleRoomDeleted() {
    displayMessage("💥 A sala foi deletada pelo criador", "error");
    leaveRoom();
}

function startGame() {
    if (!currentRoom || !isAdmin) return;
    
    // Efeito visual de loading
    elements.startGameButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Iniciando...';
    elements.startGameButton.disabled = true;
    
    // Emite para o servidor iniciar o jogo
    socket.emit('startGame', currentRoom, (response) => {
        if (!response.success) {
            displayMessage(`❌ ${response.error}`, "error");
            updateStartButton(elements.playersList.children.length);
            elements.startGameButton.disabled = true;
        }
    });
}

// Event listeners
function setupEventListeners() {
    // Validação de nome
    elements.validateNicknameButton.addEventListener("click", validateNickname);
    elements.startGameButton.addEventListener("click", startGame);

    elements.changeNameButton.addEventListener("click", () => {
        if (!currentRoom) {
            playerName = null;
            elements.playerName.disabled = false;
            elements.validateNicknameButton.disabled = false;
            elements.changeNameButton.style.display = "none";
            elements.roomControls.style.display = "none";
            elements.playerName.value = "";
            elements.playerName.focus();
        }
    });
    
    elements.playerName.addEventListener("keypress", (e) => {
        if (e.key === "Enter") validateNickname();
    });
    
    // Controles de sala
    elements.roomType.addEventListener("change", function() {
        elements.passwordField.style.display = this.value === 'private' ? 'block' : 'none';
    });
    
    elements.createRoomButton.addEventListener("click", createRoom);
    elements.leaveButton.addEventListener("click", leaveRoom);
    elements.searchRoomButton.addEventListener("click", updateRoomList);
    
    // Eventos do Chat
    elements.messageInput.addEventListener("keypress", (e) => {
        if (e.key === "Enter") sendMessage();
    });
    
    let typingTimer;
    elements.messageInput.addEventListener("input", () => {
        if (!currentRoom) return;
        
        socket.emit('typing', {
            roomCode: currentRoom,
            name: playerName,
            isTyping: elements.messageInput.value.length > 0
        });
        
        clearTimeout(typingTimer);
        
        if (elements.messageInput.value.length > 0) {
            typingTimer = setTimeout(() => {
                socket.emit('typing', {
                    roomCode: currentRoom,
                    name: playerName,
                    isTyping: false
                });
            }, 2000);
        }
    });
    
    elements.sendMessageButton.addEventListener("click", sendMessage);
    elements.deleteRoomButton.addEventListener("click", deleteRoom);
    
    // Toggle do Chat
    elements.chatToggle.addEventListener("click", () => {
        if (!currentRoom) {
            displayMessage("⚠️ Entre em uma sala para usar o chat", "error");
            return;
        }
        
        const isActive = elements.chatBoxContainer.classList.toggle("active");
        elements.chatBoxContainer.style.display = isActive ? "flex" : "none";
        
        if (isActive) {
            unreadMessages = 0;
            updateChatNotification();
        }
        
        elements.chatToggle.style.transform = "scale(0.9)";
        setTimeout(() => {
            elements.chatToggle.style.transform = isActive 
                ? "scale(1.1) rotate(10deg)" 
                : "scale(1)";
        }, 200);
    });
}

// Inicialização
document.addEventListener('DOMContentLoaded', () => {
    initSocket();
    elements.chatBoxContainer.style.display = "none";
    elements.chatBoxContainer.classList.remove("active");
});